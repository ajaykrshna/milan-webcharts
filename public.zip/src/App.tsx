import React from 'react'
import Chart from './Chart'
import Change from './Todata'
import Test from './Test'
import MainPage from './MainPage'

function App() {
  return (
    <div className='App'>
      {/* <Chart />
      <Change /> */}
      <MainPage/>
    </div>
  )
}

export default App;
