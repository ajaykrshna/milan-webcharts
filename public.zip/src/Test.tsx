import React from 'react'
import { Graphs } from './Graphs'

export default function Test(){
  return(
    <div>
    <Graphs sportsIndex={0}/>
    </div>
  )
}